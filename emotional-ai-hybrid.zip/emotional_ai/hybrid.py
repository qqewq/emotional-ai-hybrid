
"""Hybrid resonance system (toy GAN+RL style loop).
This is a *minimal* educational prototype demonstrating the workflow:
- generator proposes hypotheses (signals)
- resonance filter scores them against a target
- RL-like update nudges generator parameters toward higher scores
"""
from dataclasses import dataclass
import numpy as np
from .resonance import spectral_overlap, standing_wave
from .ethics import EthicalFilter

@dataclass
class HybridConfig:
    dt: float = 0.01
    steps: int = 200
    pop_size: int = 16
    lr: float = 0.05
    noise: float = 0.05

class HybridResonanceSystem:
    def __init__(self, target_signal, cfg: HybridConfig | None = None, ethics: EthicalFilter | None = None):
        self.target = np.asarray(target_signal, dtype=float)
        self.cfg = cfg or HybridConfig()
        self.ethics = ethics or EthicalFilter()
        # generator parameter: frequency; start random-ish
        self.gen_freq = 2.0

    def _gen_candidate(self, n, dt, noise, seed=None):
        t, x = standing_wave(n=n, dt=dt, freq=max(0.1, self.gen_freq), noise=noise, seed=seed or 0)
        return x

    def step(self):
        n = len(self.target)
        scores = []
        freqs = []
        for k in range(self.cfg.pop_size):
            cand = self._gen_candidate(n, self.cfg.dt, self.cfg.noise, seed=k)
            s = spectral_overlap(cand, self.target, dt=self.cfg.dt)
            ethics_score = 0.7  # placeholder constant (could be learned)
            ok = self.ethics.approve(s, ethics_score)
            scores.append(s if ok else 0.0)
            freqs.append(self.gen_freq)
        mean_score = float(np.mean(scores))
        # gradient-free nudging: if score improved by trying a small delta in freq, keep it
        trial = self.gen_freq * (1.0 + (self.cfg.lr if mean_score < 0.9 else -self.cfg.lr/2))
        # Evaluate trial
        cand = self._gen_candidate(n, self.cfg.dt, self.cfg.noise, seed=999)
        base = spectral_overlap(self._gen_candidate(n, self.cfg.dt, self.cfg.noise, seed=998), self.target, dt=self.cfg.dt)
        trial_score = spectral_overlap(self._gen_candidate(n, self.cfg.dt, self.cfg.noise, seed=997), self.target, dt=self.cfg.dt)
        if trial_score >= base:
            self.gen_freq = max(0.1, trial)
        return dict(mean_score=mean_score, gen_freq=self.gen_freq)

    def run(self):
        history = []
        for _ in range(self.cfg.steps):
            h = self.step()
            history.append(h)
        return history
