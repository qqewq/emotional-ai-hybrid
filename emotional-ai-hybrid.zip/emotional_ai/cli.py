
import argparse
import numpy as np
from .resonance import standing_wave, spectral_overlap

def main():
    parser = argparse.ArgumentParser(description="Emotional AI resonance tools")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_overlap = sub.add_parser("overlap", help="Compute spectral overlap between synthetic standing wave and itself")
    p_overlap.add_argument("--freq", type=float, default=3.0, help="Base frequency")
    p_overlap.add_argument("--noise", type=float, default=0.05, help="Noise std")
    p_overlap.add_argument("--n", type=int, default=2048, help="Signal length")
    p_overlap.add_argument("--dt", type=float, default=0.01, help="Sample step")

    args = parser.parse_args()

    if args.cmd == "overlap":
        t, s = standing_wave(n=args.n, dt=args.dt, freq=args.freq, noise=args.noise, seed=0)
        overlap = spectral_overlap(s, s, dt=args.dt)
        print(f"Spectral overlap (self): {overlap:.6f}")
        print("OK")

if __name__ == "__main__":
    main()
