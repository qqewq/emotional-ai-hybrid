
import argparse
import numpy as np
from emotional_ai.resonance import standing_wave, spectral_overlap

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--freq", type=float, default=3.0)
    ap.add_argument("--noise", type=float, default=0.05)
    ap.add_argument("--n", type=int, default=4096)
    ap.add_argument("--dt", type=float, default=0.01)
    args = ap.parse_args()

    t, s1 = standing_wave(n=args.n, dt=args.dt, freq=args.freq, noise=args.noise, seed=0)
    t, s2 = standing_wave(n=args.n, dt=args.dt, freq=args.freq*1.01, noise=args.noise, seed=1)
    ov_same = spectral_overlap(s1, s1, dt=args.dt)
    ov_near = spectral_overlap(s1, s2, dt=args.dt)

    print(f"Self overlap: {ov_same:.6f}  (должен быть ~1.0)")
    print(f"Near overlap: {ov_near:.6f}  (чуть ниже из-за частотного сдвига)")

if __name__ == "__main__":
    main()
